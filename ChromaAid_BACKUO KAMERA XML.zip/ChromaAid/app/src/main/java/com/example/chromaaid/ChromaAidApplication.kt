package com.example.chromaaid

import android.app.Application
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatDelegate
import androidx.preference.PreferenceManager
import com.example.chromaaid.view.ui.screen.setting.DarkMode
import java.util.Locale

class ChromaAidApplication : Application() {
    override fun onCreate() {
        super.onCreate()

        val preferences = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        preferences.getString(
            getString(R.string.pref_key_dark),
            getString(R.string.pref_dark_follow_system)
        )?.apply {
            val mode = DarkMode.valueOf(this.uppercase(Locale.US))
            AppCompatDelegate.setDefaultNightMode(mode.value)
        }

    }
//    private fun setupLocale() {
//        val languageCode = getLanguageCodeFromPreferences()
//        val locale = Locale(languageCode)
//        Locale.setDefault(locale)
//
//        val configuration = Configuration()
//        configuration.setLocale(locale)
//
//        resources.updateConfiguration(configuration, resources.displayMetrics)
//    }
//    private fun getLanguageCodeFromPreferences(): String {
//        return PreferenceManager.getDefaultSharedPreferences(this)
//            .getString(getString(R.string.pref_key_language), "en") ?: "en"
//    }
}