package com.example.chromaaid.view

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.chromaaid.R
import com.example.chromaaid.view.ui.Navigation.NavigationItem
import com.example.chromaaid.view.ui.Navigation.Screen
import com.example.chromaaid.view.ui.screen.home.HomeScreen
import com.example.chromaaid.view.ui.screen.person.PersonScreen
import com.example.chromaaid.view.ui.screen.scanner.ScanActivity
import com.example.chromaaid.view.ui.screen.setting.SettingActivity
//import com.example.chromaaid.view.ui.screen.scanner.ColorDetectViewModel
//import com.example.chromaaid.view.ui.screen.scanner.ScanScreen
import com.example.chromaaid.view.ui.theme.ChromaAidTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChromaAidApp (
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController(),
    context: Context
) {
    Scaffold(
    bottomBar = {
            BottomBar(navController)
    },
    modifier = modifier
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = androidx.compose.ui.Modifier.padding(innerPadding)
        ){
            composable(Screen.Home.route) {
                HomeScreen(context = context)
            }
            composable(Screen.Profile.route) {
                PersonScreen(context = context)
            }
        }
    }


}

@Composable
private fun BottomBar(
    navController: NavHostController,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier,
        contentColor = Color.Transparent
    ) {
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry?.destination?.route

        val navigationItems = listOf(
            NavigationItem(
                title = stringResource(R.string.menu_home),
                icon = Icons.Default.Home,
                screen = Screen.Home
            ),
            NavigationItem(
                title = stringResource(R.string.menu_Person),
                icon = Icons.Default.Person,
                screen = Screen.Profile
            ),
        )
        navigationItems.map { item ->
            val isSelected = currentRoute == item.screen.route
            NavigationBarItem(
                icon = {
                    val iconColor = if (isSelected) {
                        colorResource(id = R.color.blue_light)
                    } else {
                        Color.Gray
                    }
                    Icon(
                        imageVector = item.icon,
                        tint = iconColor,
                        contentDescription = item.title,
                        modifier = Modifier
                            .size(36.dp)
                    )
                },
                selected = isSelected,
                onClick = {
                    navController.navigate(item.screen.route) {
                        popUpTo(navController.graph.findStartDestination().id) {
                            saveState = true
                        }
                        restoreState = true
                        launchSingleTop = true
                    }
                }
            )
        }
    }
}