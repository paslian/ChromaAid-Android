//package com.example.chromaaid.view.ui.screen.scanner
//
//import androidx.camera.core.CameraSelector
//import androidx.camera.core.ImageAnalysis
//import androidx.camera.core.ImageCapture
//import androidx.camera.core.ImageProxy
//import androidx.camera.core.Preview
//import androidx.camera.lifecycle.ProcessCameraProvider
//import androidx.camera.view.PreviewView
//import androidx.compose.runtime.State
//import androidx.compose.runtime.mutableStateOf
//import androidx.compose.ui.graphics.Color
//import androidx.core.content.ContextCompat
//import androidx.lifecycle.LifecycleOwner
//import androidx.lifecycle.ViewModel
//import kotlinx.coroutines.flow.MutableStateFlow
//import kotlinx.coroutines.flow.StateFlow
//import java.util.concurrent.ExecutorService
//import java.util.concurrent.Executors
//
//class ColorDetectViewModel : ViewModel() {
//
//    private var cameraProvider: ProcessCameraProvider? = null
//    private var imageCapture: ImageCapture? = null
//    private var cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()
//
////    , onColorDetected: (Color) -> Unit
//    fun initCamera(previewView: PreviewView, lifecycleOwner: LifecycleOwner) {
//        val context = previewView.context
//        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
//        cameraProviderFuture.addListener({
//            cameraProvider = cameraProviderFuture.get()
//
//            // Build and bind the camera use cases
//            val preview = Preview.Builder().build().also {
//                it.setSurfaceProvider(previewView.surfaceProvider)
//            }
//
//            imageCapture = ImageCapture.Builder().build()
//
//            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
//
//            try {
//                cameraProvider?.unbindAll()
//                cameraProvider?.bindToLifecycle(
//                    lifecycleOwner,
//                    cameraSelector,
//                    preview,
//                    imageCapture
//                )
//
////                setupImageAnalyzer(onColorDetected)
//            } catch (e: Exception) {
//                e.printStackTrace()
//            }
//        }, ContextCompat.getMainExecutor(context))
//    }
//
////    private fun setupImageAnalyzer(onColorDetected: (Color) -> Unit) {
////        val imageAnalyzer = ImageAnalysis.Builder()
////            .build()
////            .also {
////                it.setAnalyzer(cameraExecutor, { image ->
////                    // Implement your color detection logic here
////                    // You may use the ColorDetectHandler or any other method
////                    val color = detectColor(image)
////                    onColorDetected(color)
////                    image.close()
////                })
////            }
////
////        cameraProvider?.bindToLifecycle(/* lifecycleOwner= */ null, CameraSelector.DEFAULT_BACK_CAMERA, imageAnalyzer)
////    }
//
////    private fun detectColor(image: ImageProxy): Color {
////        // Implement your color detection logic here
////        // You may use the ColorDetectHandler or any other method
////        // Return the detected color
////    }
//
//    fun releaseCamera() {
//        cameraProvider?.unbindAll()
//        cameraExecutor.shutdown()
//    }
//
//    private val _flashState = MutableStateFlow(false)
//    val flashState: StateFlow<Boolean> = _flashState
//
//
//    fun toggleFlash() {
//        _flashState.value = !_flashState.value
//
//        // Toggle the flash mode
//        val newFlashMode = if (_flashState.value) {
//            ImageCapture.FLASH_MODE_ON
//        } else {
//            ImageCapture.FLASH_MODE_OFF
//        }
//
//        // Update the flash mode if the ImageCapture is available
//        imageCapture?.flashMode = newFlashMode
//    }
//
//    // Call this function to set the ImageCapture instance associated with CameraX
//    fun setImageCapture(imageCapture: ImageCapture) {
//        this.imageCapture = imageCapture
//    }
//}