//package com.example.chromaaid.view.ui.screen.scanner
//
//import android.Manifest
//import android.content.Context
//import android.content.pm.PackageManager
//import android.widget.Toast
//import androidx.activity.compose.rememberLauncherForActivityResult
//import androidx.activity.result.contract.ActivityResultContracts
//import androidx.camera.view.PreviewView
//import androidx.compose.foundation.Image
//import androidx.compose.foundation.background
//import androidx.compose.foundation.clickable
//import androidx.compose.foundation.layout.Arrangement
//import androidx.compose.foundation.layout.Box
//import androidx.compose.foundation.layout.PaddingValues
//import androidx.compose.foundation.layout.Row
//import androidx.compose.foundation.layout.fillMaxWidth
//import androidx.compose.foundation.layout.height
//import androidx.compose.foundation.layout.padding
//import androidx.compose.foundation.layout.width
//import androidx.compose.foundation.lazy.LazyColumn
//import androidx.compose.foundation.lazy.rememberLazyListState
//import androidx.compose.foundation.shape.CircleShape
//import androidx.compose.foundation.shape.RoundedCornerShape
//import androidx.compose.material3.Divider
//import androidx.compose.material3.MaterialTheme
//import androidx.compose.runtime.Composable
//import androidx.compose.runtime.DisposableEffect
//import androidx.compose.runtime.LaunchedEffect
//import androidx.compose.runtime.rememberUpdatedState
//import androidx.compose.ui.Alignment
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.draw.alpha
//import androidx.compose.ui.draw.clip
//import androidx.compose.ui.graphics.Color
//import androidx.compose.ui.layout.ContentScale
//import androidx.compose.ui.platform.LocalLifecycleOwner
//import androidx.compose.ui.res.painterResource
//import androidx.compose.ui.unit.dp
//import androidx.compose.ui.viewinterop.AndroidView
//import androidx.core.content.ContextCompat
//import com.example.chromaaid.R
//import com.example.chromaaid.view.ui.screen.setting.SettingButton
//import androidx.compose.runtime.collectAsState
//import androidx.compose.runtime.getValue
//
//
////class ScanScreen : ComponentActivity() {
////    override fun onCreate(savedInstanceState: Bundle?) {
////        super.onCreate(savedInstanceState)
////        setContent {
////            ChromaAidTheme {
////                // A surface container using the 'background' color from the theme
////                Surface(
////                    modifier = Modifier.fillMaxSize(),
////                    color = MaterialTheme.colorScheme.background
////                ) {
////
////                }
////            }
////        }
////    }
////}
//
//@Composable
//fun ScanScreen(
//    modifier: Modifier = Modifier,
//    viewModel: ColorDetectViewModel,
//    context: Context,
//){
//    val previewView = rememberUpdatedState(newValue = PreviewView(context))
//    val lifecycleOwner = LocalLifecycleOwner.current
//    val flashState by viewModel.flashState.collectAsState()
//
//    val cameraPermissionLauncher =
//        rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
//            if (isGranted) {
//                viewModel.initCamera(previewView.value, lifecycleOwner)
//                Toast.makeText(
//                    context,
//                    "Camera active.",
//                    Toast.LENGTH_SHORT
//                ).show()
//            } else {
//                Toast.makeText(
//                    context,
//                    "Camera permission is required.",
//                    Toast.LENGTH_SHORT
//                ).show()
//            }
//        }
//
//    val isCameraPermissionGranted =
//        ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
//                PackageManager.PERMISSION_GRANTED
//
//    Box(modifier = modifier) {
//        val listState = rememberLazyListState()
//        LazyColumn(
//            state = listState,
//            contentPadding = PaddingValues(bottom = 20.dp)
//        ) {
//            item {
//                Row(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .padding(20.dp),
//                    horizontalArrangement = Arrangement.SpaceBetween
//                ) {
//                    Image(
//                        painter = painterResource(id = R.drawable.logo),
//                        contentDescription = null,
//                        contentScale = ContentScale.Crop,
//                        modifier = Modifier
//                            .width(115.dp)
//                            .height(74.dp)
//                    )
//                    SettingButton(modifier = Modifier.padding(8.dp), context = context)
//
//                }
//                Divider(
//                    color = MaterialTheme.colorScheme.onBackground,
//                    thickness = 1.dp,
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .padding(horizontal = 14.dp)
//                )
//                AndroidView(
//                    factory = { context ->
//                        PreviewView(context).apply {
//
//                        }
//                    },
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .height(500.dp)
//                        .padding(20.dp)
//                        .clip(RoundedCornerShape(20.dp))
//                ) { view ->
//                    if (isCameraPermissionGranted) {
//                        viewModel.initCamera(view, lifecycleOwner)
//                        viewModel.releaseCamera()
//                    } else {
//                        cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
//                    }
////                    // Initialize the camera in the Composable
////                    LaunchedEffect(Unit) {
////                        viewModel.initCamera(view, lifecycleOwner) {
////                            // onColorDetected logic
////                        }
////                    }
////
////                    DisposableEffect(context) {
////                        onDispose {
////                            // Release the camera when the composable is disposed
////                            viewModel.releaseCamera()
////                        }
////                    }
//                }
//                Row(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .padding(horizontal = 50.dp),
//                    horizontalArrangement = Arrangement.SpaceBetween,
//                    verticalAlignment = Alignment.CenterVertically
//                ) {
//                    Image(
//                        painter = painterResource(id = R.drawable.baseline_cameraswitch_24),
//                        contentDescription = "image description",
//                        modifier = Modifier
//                            .width(50.dp)
//                            .height(50.dp)
//                            .clip(CircleShape)
//                            .background(Color.Gray)
//                            .padding(10.dp)
//                    )
//                    Image(
//                        painter = painterResource(id = R.drawable.baseline_camera_24),
//                        contentDescription = "image description",
//                        contentScale = ContentScale.Crop,
//                        modifier = Modifier
//                            .width(70.dp)
//                            .height(70.dp)
//                    )
//                    Image(
//                        painter = painterResource(id = R.drawable.baseline_flash_off_24),
//                        contentDescription = "image description",
//                        modifier = Modifier
//                            .width(50.dp)
//                            .height(50.dp)
//                            .clip(CircleShape)
//                            .background(Color.Gray)
//                            .padding(10.dp)
//                            .clickable {
//                                // Disable the button during camera initialization
//                                if (isCameraPermissionGranted ) {
//                                    viewModel.toggleFlash()
//                                }
//                            }
//                    )
//
//                }
//            }
//        }
//    }
//}
