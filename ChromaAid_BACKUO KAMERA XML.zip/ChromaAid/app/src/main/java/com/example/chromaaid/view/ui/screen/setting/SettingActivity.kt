package com.example.chromaaid.view.ui.screen.setting

import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.provider.Settings
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.preference.ListPreference
import androidx.preference.PreferenceFragmentCompat
import com.example.chromaaid.R
import java.util.Locale


class SettingActivity : AppCompatActivity() {
    fun onBackClick(view: View?) {
        finish()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)
        if (savedInstanceState == null) {
            supportFragmentManager
                .beginTransaction()
                .replace(R.id.settings, SettingsFragment())
                .commit()
        }
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }
    class SettingsFragment : PreferenceFragmentCompat() {
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.root_preferences, rootKey)

            val themePreference = findPreference<ListPreference>(getString(R.string.pref_key_dark))
            val languagePreference = findPreference<ListPreference>(getString(R.string.pref_key_language))


            themePreference?.setOnPreferenceChangeListener { _, newValue ->
                val changetheme = DarkMode.valueOf(newValue.toString().uppercase(Locale.US))
                updateTheme(changetheme.value)

                true
            }

            val titleKey = getString(R.string.pref_language_title)
            if (titleKey == "Bahasa") {
                languagePreference?.summary = "Indonesia"
            } else {
                languagePreference?.summary = "English"
            }

            languagePreference?.setOnPreferenceClickListener {
                startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS))
                true
            }

        }

        private fun updateTheme(mode: Int): Boolean {
            AppCompatDelegate.setDefaultNightMode(mode)
            requireActivity().recreate()
            return true
        }
    }
}
