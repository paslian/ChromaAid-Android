package com.example.chromaaid.view.ui.screen.setting

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingButton(modifier: Modifier = Modifier, context: Context) {
    Row(
        modifier = modifier
            .clickable {
                val intent = Intent(context, SettingActivity::class.java)
                context.startActivity(intent)
            }
            .padding(8.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Settings,
            contentDescription = null,
            modifier = Modifier.size(40.dp)
        )
    }
}